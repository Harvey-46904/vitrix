<?php

namespace Wave\Http\Livewire\Settings;

use Livewire\Component;

class Invoices extends Component
{
    public function render()
    {
        return view('theme::livewire.settings.invoices');
    }
}
